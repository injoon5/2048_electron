# 2048 OIJ
A small clone of [2048](https://play2048.co/).

Made just for fun. [Play it here!](https://2048.injoon5.ga)

### Screenshot

<p align="center">
  <img src="https://cloud.githubusercontent.com/assets/1175750/8614312/280e5dc2-26f1-11e5-9f1f-5891c3ca8b26.png" alt="Screenshot"/>
</p>

That screenshot is fake, by the way. I never reached 2048 :smile:


