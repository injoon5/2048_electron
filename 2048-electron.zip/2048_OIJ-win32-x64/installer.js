var electronInstaller = require('electron-winstaller');

resultPromise = electronInstaller.createWindowsInstaller({
    appDirectory: './dist/2048_OIJ-win32-x64',
    outputDirectory: './dist/installer-win32-x64',
    exe: '2048_OIJ',
    setupExe: '2048_OIJSetup.exe'
});

resultPromise.then(function () {
    console.log("It worked!");
}, function (e) {
    console.log('No dice: ' + e.message);
});